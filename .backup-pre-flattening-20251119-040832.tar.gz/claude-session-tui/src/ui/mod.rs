//! Minimal UI module to get the TUI running end-to-end.

pub mod app;

pub use app::App;
